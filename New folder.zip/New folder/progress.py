from db_config import get_connection

def update_progress(enroll_id, module_id, percent, time_spent):
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Ensure integer percent and clamp to [0,100]
        try:
            pct = int(round(float(percent)))
        except Exception:
            pct = 0
        pct = max(0, min(100, pct))
        cur.execute(
            "INSERT INTO progress(enrollment_id,module_id,completion_percentage,time_spent_minutes) VALUES(%s,%s,%s,%s)",
            (enroll_id, module_id, pct, int(time_spent))
        )
        conn.commit()
        print("📈 Progress Updated Successfully")
    finally:
        cur.close()
        conn.close()
