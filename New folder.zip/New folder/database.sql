CREATE DATABASE advanced_lms;
USE advanced_lms;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255),
    role ENUM('Student','Instructor','Admin'),
    status ENUM('Active','Blocked') DEFAULT 'Active'
);

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100)
);

CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(150),
    category_id INT,
    instructor_id INT,
    duration_hours INT,
    level ENUM('Beginner','Intermediate','Advanced'),
    status ENUM('Active','Archived'),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (instructor_id) REFERENCES users(user_id)
);

CREATE TABLE modules (
    module_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT,
    module_name VARCHAR(150),
    sequence_no INT,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    enroll_date DATE,
    status ENUM('Enrolled','Completed','Dropped'),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE progress (
    progress_id INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_id INT,
    module_id INT,
    completion_percentage INT,
    time_spent_minutes INT,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),
    FOREIGN KEY (module_id) REFERENCES modules(module_id)
);
