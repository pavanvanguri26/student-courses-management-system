from db_config import get_connection

# category_id is optional to match calls from main.py; when omitted, NULL is inserted
# level must match ENUM('Beginner','Intermediate','Advanced')

def add_course(name, instructor_id, duration, level, category_id=None):
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Normalize level capitalization to match ENUM
        level_norm = str(level).capitalize()
        cur.execute(
            "INSERT INTO courses(course_name,category_id,instructor_id,duration_hours,level,status) VALUES(%s,%s,%s,%s,%s,'Active')",
            (name, category_id, instructor_id, duration, level_norm)
        )
        conn.commit()
        print("📘 Course Added Successfully")
    finally:
        cur.close()
        conn.close()


def add_module(course_id, module_name, seq):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO modules(course_id,module_name,sequence_no) VALUES(%s,%s,%s)",
            (course_id, module_name, seq)
        )
        conn.commit()
        print("📂 Module Added Successfully")
    finally:
        cur.close()
        conn.close()
