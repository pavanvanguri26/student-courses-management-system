from db_config import get_connection

def enroll_student(user_id, course_id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO enrollments(user_id,course_id,enroll_date,status) VALUES(%s,%s,CURDATE(),'Enrolled')",
            (user_id, course_id)
        )
        conn.commit()
        print("🎓 Student Enrolled")
    finally:
        cursor.close()
        conn.close()
