import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Razak@5764",
        database="advanced_lms"
    )
