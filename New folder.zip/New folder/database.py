from mysql.connector import connect

DB_CONFIG = dict(host="localhost", user="root", password="Razak@5764")
DB_NAME = "advanced_lms"

TABLES = {}

TABLES['users'] = (
    "CREATE TABLE IF NOT EXISTS users ("
    " user_id INT AUTO_INCREMENT PRIMARY KEY,"
    " name VARCHAR(100) NOT NULL,"
    " email VARCHAR(100) UNIQUE NOT NULL,"
    " password_hash VARCHAR(255) NOT NULL,"
    " role ENUM('Student','Instructor','Admin') NOT NULL,"
    " status ENUM('Active','Blocked') DEFAULT 'Active'"
    ") ENGINE=InnoDB"
)

TABLES['categories'] = (
    "CREATE TABLE IF NOT EXISTS categories ("
    " category_id INT AUTO_INCREMENT PRIMARY KEY,"
    " category_name VARCHAR(100)"
    ") ENGINE=InnoDB"
)

TABLES['courses'] = (
    "CREATE TABLE IF NOT EXISTS courses ("
    " course_id INT AUTO_INCREMENT PRIMARY KEY,"
    " course_name VARCHAR(150),"
    " category_id INT,"
    " instructor_id INT,"
    " duration_hours INT,"
    " level ENUM('Beginner','Intermediate','Advanced'),"
    " status ENUM('Active','Archived') DEFAULT 'Active',"
    " FOREIGN KEY (category_id) REFERENCES categories(category_id),"
    " FOREIGN KEY (instructor_id) REFERENCES users(user_id)"
    ") ENGINE=InnoDB"
)

TABLES['modules'] = (
    "CREATE TABLE IF NOT EXISTS modules ("
    " module_id INT AUTO_INCREMENT PRIMARY KEY,"
    " course_id INT,"
    " module_name VARCHAR(150),"
    " sequence_no INT,"
    " FOREIGN KEY (course_id) REFERENCES courses(course_id)"
    ") ENGINE=InnoDB"
)

TABLES['enrollments'] = (
    "CREATE TABLE IF NOT EXISTS enrollments ("
    " enrollment_id INT AUTO_INCREMENT PRIMARY KEY,"
    " user_id INT,"
    " course_id INT,"
    " enroll_date DATE,"
    " status ENUM('Enrolled','Completed','Dropped') DEFAULT 'Enrolled',"
    " FOREIGN KEY (user_id) REFERENCES users(user_id),"
    " FOREIGN KEY (course_id) REFERENCES courses(course_id)"
    ") ENGINE=InnoDB"
)

TABLES['progress'] = (
    "CREATE TABLE IF NOT EXISTS progress ("
    " progress_id INT AUTO_INCREMENT PRIMARY KEY,"
    " enrollment_id INT,"
    " module_id INT,"
    " completion_percentage INT,"
    " time_spent_minutes INT,"
    " FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),"
    " FOREIGN KEY (module_id) REFERENCES modules(module_id)"
    ") ENGINE=InnoDB"
)


def create_database_and_tables():
    # Create database if not exists (connect without selecting DB)
    cnx = connect(**DB_CONFIG)
    cur = cnx.cursor()
    try:
        cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME} DEFAULT CHARACTER SET 'utf8mb4'")
    finally:
        cur.close()
        cnx.close()

    # Connect to the created database and ensure all tables exist
    cnx = connect(database=DB_NAME, **DB_CONFIG)
    cur = cnx.cursor()
    try:
        for name, ddl in TABLES.items():
            cur.execute(ddl)
        cnx.commit()
        print("✅ Database and tables ensured")
    finally:
        cur.close()
        cnx.close()


if __name__ == "__main__":
    create_database_and_tables()
