from user import register_user, login_user
from course import add_course
from enrollment import enroll_student
from progress import update_progress
from reports import student_report, course_report

current_user = None
current_role = None

def login():
    global current_user, current_role
    email = input("Email: ")
    password = input("Password: ")
    user_id, role = login_user(email, password)
    if user_id:
        current_user = user_id
        current_role = (role or "").lower()
        return True
    return False

while True:
    if not current_user:
        print("\n1.Register\n2.Login\n3.Exit")
        ch = input("Choose: ")
        if ch == "1":
            name = input("Name: ")
            email = input("Email: ")
            password = input("Password: ")
            role = input("Role (student/instructor): ").lower()
            if role not in ['student', 'instructor']:
                print("❌ Invalid role")
                continue
            register_user(name, email, password, role)
        elif ch == "2":
            if login():
                continue
        elif ch == "3":
            break
        else:
            print("❌ Invalid choice")
    else:
        print(f"\nLogged in as {current_role}")
        print("1.Add Course (Instructor)\n2.Enroll in Course (Student)\n3.Update Progress (Student)\n4.View Reports\n5.Logout")
        ch = input("Choose: ")
        if ch == "1" and current_role == "instructor":
            name = input("Course Name: ")
            duration = int(input("Duration (hours): "))
            level = input("Level (Beginner/Intermediate/Advanced): ")
            add_course(name, current_user, duration, level)
        elif ch == "2" and current_role == "student":
            course_id = int(input("Course ID: "))
            enroll_student(current_user, course_id)
        elif ch == "3" and current_role == "student":
            enrollment_id = int(input("Enrollment ID: "))
            module_id = int(input("Module ID: "))
            percent = float(input("Completion %: "))
            time_spent = int(input("Time spent (minutes): "))
            update_progress(enrollment_id, module_id, percent, time_spent)
        elif ch == "4":
            student_report()
        elif ch == "5":
            current_user = None
            current_role = None
            print("✅ Logged out")
        else:
            print("❌ Invalid choice or permission denied")
